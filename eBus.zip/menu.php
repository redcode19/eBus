<!-- <div class="top-menu" >
    <button><img src="https://img.icons8.com/metro/50/000000/menu.png" width="20"></button>
</div> -->
<div class="back  ">
    <a href="checkplace.php"><i class="fa fa-chevron-circle-left" style="font-size:34px; color:#303030" aria-hidden="true"></i></a>
</div>
<div class="homee ">
    <a href="index.php"><img src="img/home.png" width="30" alt=""></a>
</div>
<div class="lang ">
    <button type="button" data-toggle="modal" data-target="#myModal"><img src="img/en.png" width="30" alt=""></button>
</div>

  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Languages</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            <ul>
                <li>
                    <a href="#">
                        <img src="img/en.png" width="80" alt="">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="img/ku.png" width="80" alt="">
                    </a>
                </li>
                <li>
                    <a href="#">
                        <img src="img/iq.png" width="80" alt="">
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>