<div class="container" id="loader">
    <div class="row justify-content-md-center">
        <div class="col-xs-4"></div>
        <div class="col-md-auto">
            <div class="landing-page">
                <div class="beams">
                    <center>
                        <img src="img/small-beam.png" width="15" style="margin-top: -51px;" class="img-fluid animated slideInDown" alt="">
                        <img src="img/tall-beam.png" width="15" class="img-fluid animated slideInDown"  alt="">
                    </center>
                </div>
                 <img src="img/bus.png" alt="" width="400" class=" img-fluid animated zoomIn ">
                 <h1 class="animated slideInUp">eBus</h1>
            </div>
            <img src="img/city-grey.png" style="position:fixed; bottom:0;" class=" img-fluid animated fadeInUp " alt="">
            <img src="img/city-dark.png" style="position:fixed; bottom:0;" class=" img-fluid animated fadeInUp " alt="">
        </div>
        <div class="col-xs-4"></div>        
        </div>
    </div>
</div>